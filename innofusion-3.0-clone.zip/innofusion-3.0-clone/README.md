# InnoFusion 3.0 — The Clan Wars (Clone)

A pixel-inspired, production-grade clone of **https://www.innofusion.tech/** built with **Next.js 15, TypeScript, Tailwind CSS, shadcn/ui primitives, Framer Motion, and Lucide icons.**

## ⚔️ Tech Stack

- **Next.js 15** (App Router) + **TypeScript (strict)**
- **Tailwind CSS v3.4** with a custom Clan Wars palette
- **Framer Motion** for all entry / hover / parallax animations
- **Radix UI** primitives (accordion, dialog) wrapped shadcn-style
- **Lucide React** icons
- **Zustand** for the mobile-menu / audio state
- **Next/Image** optimization for every character / background

## 🎨 Color Palette

| Token    | Hex       |
|----------|-----------|
| lilac    | `#caa8f5` |
| lavender | `#9984d4` |
| royal    | `#592e83` |
| abyss    | `#230c33` |
| bronze   | `#b27c66` |

## 🚀 Getting Started

```bash
pnpm install        # or: npm install / yarn
pnpm dev            # http://localhost:3000
pnpm build && pnpm start
```

## 📂 Project Structure

```
innofusion-3.0-clone/
├── app/
│   ├── layout.tsx
│   ├── page.tsx              # Homepage (Village + War Map + Army + Treasury + Allies + FAQ)
│   ├── globals.css
│   ├── clan-leaders/page.tsx # /clan-leaders
│   └── tracks/page.tsx       # /tracks (bonus route)
├── components/
│   ├── ui/                   # shadcn-style primitives (Button, Accordion, Sheet)
│   ├── sections/             # Hero, WarMap, Army, Treasury, Allies, FAQ, Story
│   ├── navbar.tsx
│   ├── footer.tsx
│   ├── countdown.tsx
│   └── floating-creatures.tsx
├── lib/
│   ├── utils.ts
│   ├── data.ts               # All copy, tracks, prizes, schedule, FAQs, clan leaders
│   └── store.ts              # Zustand store
├── public/images/            # Character + background assets (webp)
├── tailwind.config.ts
├── next.config.mjs
└── package.json
```

## 🚢 Deploying to Vercel

1. `git init && git add -A && git commit -m "initial"`
2. Push to GitHub.
3. On [vercel.com](https://vercel.com) → **New Project** → import the repo.
4. Framework preset: **Next.js** (auto). No env vars required.
5. Click **Deploy**.

## 🖼️ Assets

All character / background `.webp` files live in `public/images/` and came straight from the original site. Replace any of them with your own artwork — filenames referenced in `lib/data.ts` must match.

## 📜 Credits

- Theme & artwork inspired by Supercell's **Clash of Clans**.
- Original site & event: **InnoFusion 3.0**, UEM Kolkata.
