/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "www.innofusion.tech" },
      { protocol: "https", hostname: "assets.devfolio.co" },
    ],
  },
};

export default nextConfig;
