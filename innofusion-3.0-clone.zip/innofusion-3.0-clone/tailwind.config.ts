import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    container: {
      center: true,
      padding: "1rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        // Clan Wars palette
        lilac: "#caa8f5",
        lavender: "#9984d4",
        royal: "#592e83",
        abyss: "#230c33",
        bronze: "#b27c66",
        // shadcn-style tokens
        border: "rgba(202, 168, 245, 0.15)",
        input: "rgba(202, 168, 245, 0.2)",
        ring: "#9984d4",
        background: "#230c33",
        foreground: "#ede7ff",
        primary: {
          DEFAULT: "#caa8f5",
          foreground: "#230c33",
        },
        secondary: {
          DEFAULT: "#592e83",
          foreground: "#ede7ff",
        },
        muted: {
          DEFAULT: "rgba(89, 46, 131, 0.5)",
          foreground: "#caa8f5",
        },
        accent: {
          DEFAULT: "#b27c66",
          foreground: "#ede7ff",
        },
        destructive: {
          DEFAULT: "#dc2626",
          foreground: "#fafafa",
        },
        card: {
          DEFAULT: "rgba(35, 12, 51, 0.6)",
          foreground: "#ede7ff",
        },
      },
      fontFamily: {
        supercell: ["var(--font-supercell)", "Impact", "system-ui", "sans-serif"],
        display: ["var(--font-orbitron)", "system-ui", "sans-serif"],
        body: ["var(--font-rubik)", "system-ui", "sans-serif"],
      },
      borderRadius: {
        lg: "1rem",
        md: "0.75rem",
        sm: "0.5rem",
      },
      boxShadow: {
        "neon-purple": "0 0 20px rgba(202, 168, 245, 0.5), 0 0 40px rgba(152, 132, 212, 0.3)",
        "neon-inner": "inset 0 0 20px rgba(202, 168, 245, 0.2)",
        "clan": "0 8px 32px rgba(89, 46, 131, 0.6), 0 0 0 2px rgba(202, 168, 245, 0.3)",
      },
      backgroundImage: {
        "gradient-clan": "linear-gradient(135deg, #230c33 0%, #592e83 50%, #230c33 100%)",
        "gradient-neon": "linear-gradient(135deg, #caa8f5 0%, #9984d4 50%, #592e83 100%)",
        "gradient-bronze": "linear-gradient(135deg, #b27c66 0%, #caa8f5 100%)",
      },
      animation: {
        "float": "float 6s ease-in-out infinite",
        "float-slow": "float 9s ease-in-out infinite",
        "glow": "glow 2.5s ease-in-out infinite",
        "spin-slow": "spin 18s linear infinite",
        "bounce-slow": "bounce 3s ease-in-out infinite",
        "pulse-slow": "pulse 4s ease-in-out infinite",
        "shimmer": "shimmer 3s linear infinite",
        "fade-up": "fade-up 0.8s ease-out forwards",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0px) rotate(0deg)" },
          "50%": { transform: "translateY(-20px) rotate(2deg)" },
        },
        glow: {
          "0%, 100%": {
            textShadow: "0 0 10px rgba(202, 168, 245, 0.8), 0 0 20px rgba(202, 168, 245, 0.6)",
          },
          "50%": {
            textShadow: "0 0 20px rgba(202, 168, 245, 1), 0 0 40px rgba(152, 132, 212, 0.8)",
          },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(40px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;
