"use client";

import { create } from "zustand";

interface UIState {
  mobileOpen: boolean;
  setMobileOpen: (v: boolean) => void;
  audioOn: boolean;
  toggleAudio: () => void;
  nightMode: boolean;
  toggleNight: () => void;
}

export const useUI = create<UIState>((set) => ({
  mobileOpen: false,
  setMobileOpen: (v) => set({ mobileOpen: v }),
  audioOn: false,
  toggleAudio: () => set((s) => ({ audioOn: !s.audioOn })),
  nightMode: true,
  toggleNight: () => set((s) => ({ nightMode: !s.nightMode })),
}));
