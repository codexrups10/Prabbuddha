import { Shield, Clock, Swords, Trophy, Users, Crown } from "lucide-react";

export const NAV_LINKS = [
  { label: "Village", href: "/#village", icon: Shield },
  { label: "War Map", href: "/#war-map", icon: Clock },
  { label: "Army", href: "/#army", icon: Swords },
  { label: "Treasury", href: "/#treasury", icon: Trophy },
  { label: "Allies", href: "/#allies", icon: Users },
  { label: "Clan Leaders", href: "/clan-leaders", icon: Crown },
] as const;

export const EVENT = {
  name: "InnoFusion 3.0",
  tagline: "The Builder Base Awaits",
  subTagline: "Clash with Codes, Conquer with Vision!~",
  pill: "30-Hour India's Premier Software + Hardware Hackathon",
  // Target date = July 25, 2026 — 09:00 IST
  targetDate: "2026-07-25T09:00:00+05:30",
  registerUrl: "https://innofusion-3.devfolio.co/",
  venue: "University of Engineering & Management, Kolkata",
  duration: "30 Hours (Offline)",
  dates: "July 25–26, 2026",
} as const;

export const ABOUT = {
  title: "The Story of the Arena",
  paragraphs: [
    "InnoFusion is a 30-hour hackathon hosted by the University of Engineering and Management (UEM), Kolkata, bringing students from across the country together to devise innovative solutions for real-world problems. This event provides a collaborative space for students to showcase their skills, gain hands-on experience with new technologies, and create projects with societal impact.",
    "Established in 2014 and located in New Town, Kolkata, UEM offers students significant industry exposure due to its proximity to top corporates and the Netaji Subhash International Airport. Ranked among India's top 10 institutes by the NPTEL program, the IEM UEM group is recognized for its industry-focused education, fostering a culture of innovation, discipline, and excellence. With robust placement support, the group ensures promising career starts, consistently securing 1 to 2 job offers per student.",
  ],
};

export const SCHEDULE = [
  {
    title: "Registration Opens",
    date: "May 05, 2026",
    description: "The gates swing open. Rally your clan on Devfolio and submit your battle plan.",
    image: "/images/TownHall.webp",
  },
  {
    title: "Registration Closes",
    date: "May 10, 2026",
    description: "Last call, warrior. Idea submission window slams shut at midnight.",
    image: "/images/Barracks.webp",
  },
  {
    title: "Evaluation",
    date: "May 15 – Jun 20, 2026",
    description: "War chiefs weigh innovation, feasibility, and impact. Only the strongest advance.",
    image: "/images/Laboratory.webp",
  },
  {
    title: "Finalists Declaration",
    date: "June 25, 2026",
    description: "The shortlisted clans are summoned. Prepare to march on UEM Kolkata.",
    image: "/images/ClanCastle.webp",
  },
  {
    title: "Grand Finale",
    date: "July 25 – 26, 2026",
    description: "30 hours of non-stop building, testing and pitching at UEM Kolkata.",
    image: "/images/TrophyStand.webp",
  },
] as const;

export const TRACKS = [
  {
    name: "Artificial Intelligence & ML",
    description:
      "Summon intelligent agents, train vision models, and weaponize data to solve wicked problems.",
    icon: "🧠",
    image: "/images/Wizard.webp",
  },
  {
    name: "Hardware, Robotics & IoT",
    description:
      "Build physical machines, embedded systems, and connected devices — solder, sensors and all.",
    icon: "🤖",
    image: "/images/P.E.K.K.A.webp",
  },
  {
    name: "Web & App Development",
    description:
      "Ship a polished full-stack product in 30 hours. Frontend flair, backend muscle, mobile reach.",
    icon: "💻",
    image: "/images/Giant.webp",
  },
  {
    name: "Cybersecurity",
    description:
      "Defend the realm. Red-team, blue-team, build tooling that keeps attackers out of the vault.",
    icon: "🛡️",
    image: "/images/ShieldClan_Badge_Icon.webp",
  },
  {
    name: "Open Innovation",
    description:
      "No restrictions. If it's bold, useful and unusual — this is the track for you.",
    icon: "✨",
    image: "/images/Barbarian.webp",
  },
  {
    name: "Blockchain & Web3",
    description:
      "Smart contracts, on-chain experiences, zk-magic and everything in between.",
    icon: "⛓️",
    image: "/images/ArcherQueen.webp",
  },
] as const;

export const PRIZES = [
  { rank: "Grand Champion", amount: "$20,350", sponsor: "Wolfram", accent: "from-[#caa8f5] to-[#9984d4]" },
  { rank: "Elite Warrior",  amount: "$4,320",  sponsor: "CodeCrafters", accent: "from-[#b27c66] to-[#caa8f5]" },
  { rank: "Chain Master",   amount: "$3,750",  sponsor: ".xyz Domains", accent: "from-[#9984d4] to-[#592e83]" },
  { rank: "Automation King",amount: "$3,519",  sponsor: "N8N", accent: "from-[#caa8f5] to-[#b27c66]" },
  { rank: "AI Conqueror",   amount: "$1,900",  sponsor: "navan.ai", accent: "from-[#592e83] to-[#9984d4]" },
  { rank: "Hackathon Loot", amount: "$870",    sponsor: "InnoFusion 3.0", accent: "from-[#caa8f5] to-[#592e83]" },
  { rank: "Frontend Fury",  amount: "$500",    sponsor: "Vercel", accent: "from-[#9984d4] to-[#caa8f5]" },
  { rank: "Tool Master",    amount: "$430",    sponsor: "Wadhwani Foundation", accent: "from-[#b27c66] to-[#9984d4]" },
  { rank: "Board Legend",   amount: "$200",    sponsor: "Miro", accent: "from-[#caa8f5] to-[#9984d4]" },
  { rank: "Subnet Ruler",   amount: "$200",    sponsor: "Avalanche", accent: "from-[#592e83] to-[#caa8f5]" },
  { rank: "Ethereum Edge",  amount: "$100",    sponsor: "ETHIndia", accent: "from-[#9984d4] to-[#b27c66]" },
] as const;

export const PRIZE_POOL_TOTAL = "$36,139";

export const PERKS = [
  {
    title: "Free .xyz Domain",
    body: "InnoFusion 3.0 participants receive 250 free .xyz domains for 1 year to host hackathon projects and establish professional digital identities.",
  },
  {
    title: "Knowledge Arsenal",
    body: "Workshops, mentor sessions, and partner SDKs from Vercel, Wolfram, Avalanche, Keploy, Mastra and more.",
  },
  {
    title: "National Recognition",
    body: "Winning teams get featured on Devfolio, partner platforms, and our socials to supercharge your builder brand.",
  },
  {
    title: "Swag & Certificates",
    body: "Exclusive clan merch, e-certificates for every participant, and physical trophies for the top clans.",
  },
];

export const SPONSORS = [
  { name: "Wolfram",           tier: "Champion" },
  { name: "Vercel",             tier: "Champion" },
  { name: "CodeCrafters",       tier: "Elite"    },
  { name: ".xyz Domains",       tier: "Elite"    },
  { name: "N8N",                tier: "Elite"    },
  { name: "navan.ai",           tier: "Warrior"  },
  { name: "Avalanche",          tier: "Warrior"  },
  { name: "ETHIndia",           tier: "Warrior"  },
  { name: "Wadhwani Foundation",tier: "Warrior"  },
  { name: "Miro",               tier: "Warrior"  },
  { name: "Keploy",             tier: "Ally"     },
  { name: "Edubuk",             tier: "Ally"     },
  { name: "Mastra AI",          tier: "Ally"     },
];

export const FAQS = [
  {
    q: "Who can participate?",
    a: "Any student from a recognised Indian college or university can join the battle. Bring your student ID.",
  },
  {
    q: "What is the team size?",
    a: "Teams of 1 to 4 warriors. Solo entries are welcome, but clans hit harder together.",
  },
  {
    q: "Are there any registration fees?",
    a: "None. Nada. Zero. Registration is completely free — register on Devfolio to secure your spot.",
  },
  {
    q: "Is it online or offline?",
    a: "Round 1 (Idea Submission) is online on Devfolio / HackNest. The 30-hour Grand Finale is offline at the UEM Kolkata campus.",
  },
  {
    q: "What should I bring to the venue?",
    a: "Laptop, charger, student ID, extension cords, and your hardware kits if you are on the Hardware/IoT track. Food, internet and power are on us.",
  },
  {
    q: "Do I need a finished idea to register?",
    a: "No. A rough problem statement and a willing clan is enough. You can refine it right up to the idea submission deadline on May 10.",
  },
  {
    q: "Will there be mentors?",
    a: "Yes — domain experts from our partner companies will be available throughout the hackathon for 1-on-1 sessions.",
  },
  {
    q: "What is the prize pool?",
    a: "The total prize pool stands at $36,139 across track prizes, premium partner prizes, swag, and the Grand Champion trophy.",
  },
];

export const CLAN_LEADERS = {
  organizers: [
    { name: "Diptimayee Patra",  role: "Lead Organizer" },
    { name: "MD Asif",           role: "Co-Lead Organizer" },
    { name: "Pratyay Chatterjee",role: "Co-Lead Organizer" },
    { name: "Prakash Metla",     role: "Co-Lead Organizer" },
    { name: "Manjima Dutta",     role: "Organizer" },
    { name: "Dipanjan Sheth",    role: "Organizer" },
  ],
  developers: [
    { name: "Nilanjan Saha",     role: "Developer Lead" },
    { name: "Justina Gomes",     role: "Developer Team" },
  ],
  core: [
    { name: "Srijeeta Bose",     role: "Core Team" },
    { name: "Debarun Saha",      role: "Core Team" },
    { name: "Annesha Gayen",     role: "Core Team" },
    { name: "Srija Majumdar",    role: "Core Team" },
    { name: "Sufal Poddar",      role: "Core Team" },
  ],
  graphics: [
    { name: "Preeti Dey",        role: "Graphics Lead" },
    { name: "Aritra Chatterjee", role: "Graphics Team" },
    { name: "Anindita Mondal",   role: "Graphics Team" },
    { name: "Ayushman Paul",     role: "Graphics Team" },
    { name: "Sayuri Ghosh",      role: "Graphics Team" },
    { name: "Soumi Deb Singha",  role: "Graphics Team" },
    { name: "Ankan Paul",        role: "Graphics Team" },
    { name: "Purnendu Pal",      role: "Graphics Team" },
  ],
  branding: [
    { name: "Soumajit Goswami",  role: "Branding Team Lead" },
    { name: "Soubhagya Sadhukhan", role: "Branding Team" },
  ],
  pr: [
    { name: "Sourasanta Dutta",  role: "PR Lead" },
    { name: "Sayan Adhikari",    role: "PR Team" },
    { name: "Rangan Mukherjee",  role: "PR Team" },
    { name: "Shreya Chakraborty",role: "PR Team" },
  ],
  decoration: [
    { name: "Sourav Das",        role: "Decoration Lead" },
    { name: "Srija Pahari",      role: "Decoration Team" },
    { name: "Sushmita Saha",     role: "Decoration Team" },
  ],
  coordinators: [
    { name: "Prajukta Saha",     role: "Coordinator" },
    { name: "Subarno Priyo Pandit", role: "Coordinator" },
    { name: "Pritam Paul",       role: "Coordinator" },
    { name: "Shannidhya Guha",   role: "Coordinator" },
    { name: "Sucharita Ghosh",   role: "Coordinator" },
  ],
  executive: [
    { name: "Ditipriya Laha",    role: "Executive Lead" },
    { name: "Pritim Mondal",     role: "Executive Team" },
    { name: "Priyanshu Chandra Sarker", role: "Executive Team" },
    { name: "Anish Dey",         role: "Executive Team" },
  ],
} as const;
