"use client";

import Image from "next/image";
import Link from "next/link";
import { Instagram, Twitter, Linkedin, Mail, MapPin, Github } from "lucide-react";
import { EVENT } from "@/lib/data";

export function Footer() {
  return (
    <footer id="footer" className="relative mt-24 border-t border-lilac/15 bg-abyss/80 backdrop-blur">
      <div className="starfield opacity-40" />
      <div className="container mx-auto px-5 py-14 relative">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="space-y-4 md:col-span-2">
            <Link href="/" className="inline-flex items-center gap-3">
              <Image src="/images/Innofusion3.0_Logo.webp" alt="logo" width={48} height={48} className="drop-shadow-[0_0_14px_rgba(202,168,245,0.55)]" />
              <div>
                <div className="font-display text-xl font-black text-lilac">InnoFusion 3.0</div>
                <div className="text-xs tracking-widest text-lilac/70 uppercase">The Clan Wars</div>
              </div>
            </Link>
            <p className="text-sm text-white/70 leading-relaxed max-w-md">
              India&apos;s premier 30-hour Software + Hardware Hackathon. Hosted by the University of Engineering &amp; Management, Kolkata.
              Clash with Codes, Conquer with Vision.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <SocialIcon href="https://www.instagram.com/innofusionindia/" icon={<Instagram className="h-4 w-4" />} />
              <SocialIcon href="https://twitter.com" icon={<Twitter className="h-4 w-4" />} />
              <SocialIcon href="https://linkedin.com" icon={<Linkedin className="h-4 w-4" />} />
              <SocialIcon href="https://github.com" icon={<Github className="h-4 w-4" />} />
              <SocialIcon href="mailto:innofusion@uem.edu.in" icon={<Mail className="h-4 w-4" />} />
            </div>
          </div>

          <div>
            <h4 className="font-display text-sm uppercase tracking-widest text-lilac mb-4">Battlefield</h4>
            <ul className="space-y-2 text-sm text-white/75">
              <li><a href="/#village" className="hover:text-lilac">Village</a></li>
              <li><a href="/#war-map" className="hover:text-lilac">War Map</a></li>
              <li><a href="/#army" className="hover:text-lilac">Army (Tracks)</a></li>
              <li><a href="/#treasury" className="hover:text-lilac">Treasury</a></li>
              <li><a href="/#allies" className="hover:text-lilac">Allies</a></li>
              <li><Link href="/clan-leaders" className="hover:text-lilac">Clan Leaders</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display text-sm uppercase tracking-widest text-lilac mb-4">Base Camp</h4>
            <ul className="space-y-3 text-sm text-white/75">
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5 text-lilac shrink-0" />
                <span>University of Engineering &amp; Management, New Town, Kolkata</span>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="h-4 w-4 mt-0.5 text-lilac shrink-0" />
                <a href="mailto:innofusion@uem.edu.in" className="hover:text-lilac">innofusion@uem.edu.in</a>
              </li>
              <li>
                <a
                  href={EVENT.registerUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-block mt-2 rounded-md border border-lilac/40 px-3 py-1.5 text-xs font-display tracking-widest uppercase text-lilac hover:bg-lilac/10"
                >
                  Register on Devfolio →
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-lilac/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-white/55">
          <div>© {new Date().getFullYear()} InnoFusion. Crafted by the clan at UEM Kolkata.</div>
          <div className="font-display tracking-widest text-lilac/70 uppercase">
            &quot;Clash with Codes, Conquer with Vision! ~&quot;
          </div>
        </div>
      </div>
    </footer>
  );
}

function SocialIcon({ href, icon }: { href: string; icon: React.ReactNode }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      className="h-9 w-9 grid place-items-center rounded-lg border border-lilac/30 bg-royal/40 text-lilac hover:border-lilac hover:bg-royal/70 hover:shadow-[0_0_16px_rgba(202,168,245,0.4)] transition"
    >
      {icon}
    </a>
  );
}
