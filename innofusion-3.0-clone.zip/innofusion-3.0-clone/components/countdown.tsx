"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";

function diff(target: Date) {
  const ms = target.getTime() - Date.now();
  const safe = Math.max(0, ms);
  const d = Math.floor(safe / 86400000);
  const h = Math.floor((safe % 86400000) / 3600000);
  const m = Math.floor((safe % 3600000) / 60000);
  const s = Math.floor((safe % 60000) / 1000);
  return { d, h, m, s };
}

export function Countdown({ date }: { date: string }) {
  const target = new Date(date);
  const [t, setT] = useState(diff(target));
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const id = setInterval(() => setT(diff(target)), 1000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  const cells = [
    { label: "Days",    v: t.d },
    { label: "Hours",   v: t.h },
    { label: "Minutes", v: t.m },
    { label: "Seconds", v: t.s },
  ];

  if (!mounted) return null;

  return (
    <div className="grid grid-cols-4 gap-3 sm:gap-5 max-w-2xl mx-auto">
      {cells.map((c, i) => (
        <motion.div
          key={c.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 * i, duration: 0.5 }}
          className="clan-panel p-3 sm:p-5 text-center"
        >
          <div className="font-display text-3xl sm:text-5xl font-black text-lilac drop-shadow-[0_2px_0_#230c33]">
            {String(c.v).padStart(2, "0")}
          </div>
          <div className="mt-1 text-[0.65rem] sm:text-xs tracking-widest uppercase text-lilac/70 font-display">
            {c.label}
          </div>
        </motion.div>
      ))}
    </div>
  );
}
