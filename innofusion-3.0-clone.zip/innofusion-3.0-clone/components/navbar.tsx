"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, Moon } from "lucide-react";
import { NAV_LINKS } from "@/lib/data";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useUI } from "@/lib/store";
import { cn } from "@/lib/utils";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const { mobileOpen, setMobileOpen, nightMode, toggleNight } = useUI();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={cn(
        "fixed top-4 left-1/2 z-50 -translate-x-1/2 w-[96%] max-w-[1400px] transition-all",
        scrolled && "top-2"
      )}
    >
      <div
        className={cn(
          "clan-panel flex items-center justify-between gap-4 px-3 py-2 sm:px-6 sm:py-3",
          scrolled && "backdrop-blur-xl"
        )}
      >
        {/* Logos */}
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <div className="hidden sm:flex items-center gap-1.5">
            <Image
              src="/images/UEM.webp"
              alt="UEM"
              width={36}
              height={36}
              className="h-9 w-9 object-contain drop-shadow"
            />
            <Image
              src="/images/IEM.webp"
              alt="IEM"
              width={36}
              height={36}
              className="h-9 w-9 object-contain drop-shadow"
            />
            <div className="h-7 w-px bg-lilac/30 mx-1" />
          </div>
          <Image
            src="/images/Innofusion3.0_Logo.webp"
            alt="InnoFusion"
            width={40}
            height={40}
            className="h-10 w-10 object-contain drop-shadow-[0_0_12px_rgba(202,168,245,0.5)]"
            priority
          />
        </Link>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-1">
          {NAV_LINKS.map((l) => (
            <Link
              key={l.label}
              href={l.href}
              className="group flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-display font-semibold text-white/90 transition-all hover:text-lilac hover:bg-royal/50 hover:shadow-[0_0_16px_rgba(202,168,245,0.3)]"
            >
              <l.icon className="h-4 w-4 text-lilac/80 group-hover:text-lilac transition" />
              <span className="tracking-wide">{l.label}</span>
            </Link>
          ))}
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleNight}
            aria-label="Toggle night mode"
            className="relative hidden md:grid place-items-center h-10 w-10 rounded-xl border-2 border-lilac/30 bg-royal/40 text-lilac hover:border-lilac hover:bg-royal/60 transition"
          >
            <Moon className="h-4 w-4" />
            <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] font-display tracking-widest text-lilac/80 uppercase whitespace-nowrap">
              {nightMode ? "Night Mode" : "Day Mode"}
            </span>
          </button>

          {/* Mobile trigger */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <button
                aria-label="Open menu"
                className="lg:hidden grid place-items-center h-10 w-10 rounded-xl border-2 border-lilac/30 bg-royal/50 text-lilac hover:border-lilac"
              >
                <Menu className="h-5 w-5" />
              </button>
            </SheetTrigger>
            <SheetContent>
              <AnimatePresence>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col gap-2 mt-10"
                >
                  <div className="flex items-center gap-3 pb-5 border-b border-lilac/20">
                    <Image src="/images/Innofusion3.0_Logo.webp" alt="logo" width={40} height={40} className="drop-shadow-[0_0_12px_rgba(202,168,245,0.6)]" />
                    <div>
                      <div className="font-display font-black text-lilac">InnoFusion 3.0</div>
                      <div className="text-xs text-white/60">The Clan Wars</div>
                    </div>
                  </div>
                  {NAV_LINKS.map((l, i) => (
                    <motion.div
                      key={l.label}
                      initial={{ x: 30, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: 0.05 * i }}
                    >
                      <Link
                        href={l.href}
                        onClick={() => setMobileOpen(false)}
                        className="flex items-center gap-3 rounded-lg px-4 py-3 text-base font-display text-white hover:bg-royal/60 hover:text-lilac border border-transparent hover:border-lilac/30"
                      >
                        <l.icon className="h-5 w-5 text-lilac" />
                        {l.label}
                      </Link>
                    </motion.div>
                  ))}
                </motion.div>
              </AnimatePresence>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </motion.header>
  );
}
