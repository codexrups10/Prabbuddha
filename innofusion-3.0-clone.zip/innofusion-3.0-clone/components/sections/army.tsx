"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { TRACKS } from "@/lib/data";
import { ArrowRight } from "lucide-react";

export function Army() {
  return (
    <section id="army" className="relative py-20 sm:py-28">
      <div className="container mx-auto px-5">
        <div className="text-center mb-14">
          <div className="section-subheading">🗡 Army</div>
          <h2 className="section-heading">Deploy Your Troops (Tracks)</h2>
          <p className="mt-3 max-w-2xl mx-auto text-white/70">
            Pick your battlefield. Every track has its own weapons, mentors, and sponsor-backed rewards.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {TRACKS.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: i * 0.06 }}
              whileHover={{ y: -6 }}
              className="group clan-panel p-6 relative overflow-hidden"
            >
              <div className="absolute -top-6 -right-6 w-32 h-32 opacity-25 group-hover:opacity-40 transition">
                <Image src={t.image} alt="" fill className="object-contain" />
              </div>
              <div className="text-4xl">{t.icon}</div>
              <h3 className="mt-3 font-display text-xl font-black text-lilac">{t.name}</h3>
              <p className="mt-2 text-sm text-white/75 leading-relaxed">{t.description}</p>
              <div className="mt-5 flex items-center gap-2 text-sm text-bronze font-display uppercase tracking-wider">
                <span>View Challenge</span>
                <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link href="/tracks" className="btn-ghost-clan">
            See All Tracks <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
