"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { ABOUT, EVENT } from "@/lib/data";

export function About() {
  return (
    <section className="relative py-20 sm:py-28">
      <div className="container mx-auto px-5 grid gap-10 lg:grid-cols-2 items-center">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
          className="relative"
        >
          <div className="relative aspect-square max-w-md mx-auto">
            <Image
              src="/images/ShieldClan_Badge_Icon.webp"
              alt="Clan Badge"
              fill
              className="object-contain drop-shadow-[0_20px_50px_rgba(202,168,245,0.3)]"
            />
            <motion.div
              className="absolute -top-6 -right-6 w-24 h-24"
              animate={{ rotate: [0, 10, -10, 0], y: [0, -10, 0] }}
              transition={{ duration: 6, repeat: Infinity }}
            >
              <Image src="/images/Gem_Icon.webp" alt="" width={200} height={200} className="object-contain" />
            </motion.div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
        >
          <div className="section-subheading mb-3">⚔ FINALISTS</div>
          <h2 className="section-heading mb-6">{ABOUT.title}</h2>
          <div className="space-y-4 text-white/80 leading-relaxed text-base">
            {ABOUT.paragraphs.map((p, i) => (
              <p key={i}>{p}</p>
            ))}
          </div>
          <div className="mt-8 grid grid-cols-2 sm:grid-cols-3 gap-3">
            <Stat label="Duration" value="30 Hrs" />
            <Stat label="Dates" value={EVENT.dates.replace(", 2026", "")} />
            <Stat label="Format" value="Offline" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="clan-panel px-4 py-3 text-center">
      <div className="font-display font-black text-xl text-lilac">{value}</div>
      <div className="text-[0.65rem] font-display tracking-widest uppercase text-lilac/70 mt-1">{label}</div>
    </div>
  );
}
