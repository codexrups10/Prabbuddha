"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { EVENT } from "@/lib/data";
import { Swords } from "lucide-react";

export function CTA() {
  return (
    <section className="relative py-20 sm:py-24 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(89,46,131,0.6),transparent_70%)]" />
      <div className="container mx-auto px-5 relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="clan-panel p-8 sm:p-12 text-center relative overflow-hidden"
        >
          <div className="absolute -right-10 -top-6 w-40 h-40 opacity-30">
            <Image src="/images/Gem_Icon.webp" alt="" fill className="object-contain animate-float" />
          </div>
          <div className="absolute -left-10 -bottom-6 w-40 h-40 opacity-25">
            <Image src="/images/ShieldClan_Badge_Icon.webp" alt="" fill className="object-contain animate-float-slow" />
          </div>

          <div className="section-subheading mb-3">Ready, Warrior?</div>
          <h2 className="section-heading">Lead Your Clan to Victory</h2>
          <p className="mt-4 text-white/75 max-w-2xl mx-auto">
            Registration is free. Teams of 1–4. Bring your brain, your battery packs and your hunger to ship. The arena opens on {EVENT.dates}.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <a href={EVENT.registerUrl} target="_blank" rel="noreferrer" className="btn-clan">
              <Swords className="h-5 w-5" /> Register on Devfolio
            </a>
            <a href="#war-map" className="btn-ghost-clan">View Schedule</a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
