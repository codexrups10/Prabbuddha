"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { EVENT } from "@/lib/data";
import { Countdown } from "@/components/countdown";
import { ArrowRight, Swords } from "lucide-react";

export function Hero() {
  return (
    <section id="village" className="relative min-h-[100svh] flex items-center justify-center overflow-hidden pt-24 pb-20">
      {/* Background image */}
      <Image
        src="/images/Background.webp"
        alt=""
        fill
        priority
        sizes="100vw"
        className="object-cover object-center"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-abyss/40 via-abyss/20 to-abyss" />
      <div className="starfield" />

      {/* Parallax side characters */}
      <motion.div
        className="absolute left-[2%] sm:left-[6%] bottom-[12%] w-[140px] sm:w-[220px] lg:w-[280px] z-10"
        initial={{ x: -80, opacity: 0 }}
        animate={{ x: 0, opacity: 1, y: [0, -12, 0] }}
        transition={{ x: { duration: 0.9, ease: "easeOut" }, y: { duration: 5, repeat: Infinity, ease: "easeInOut" } }}
      >
        <Image src="/images/Barbarian.webp" alt="Barbarian" width={400} height={600} className="drop-shadow-[0_20px_40px_rgba(0,0,0,0.6)]" />
      </motion.div>

      <motion.div
        className="absolute right-[2%] sm:right-[6%] bottom-[14%] w-[130px] sm:w-[200px] lg:w-[260px] z-10"
        initial={{ x: 80, opacity: 0 }}
        animate={{ x: 0, opacity: 1, y: [0, -16, 0] }}
        transition={{ x: { duration: 0.9, ease: "easeOut" }, y: { duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1 } }}
      >
        <Image src="/images/ArcherQueen.webp" alt="Archer Queen" width={400} height={600} className="drop-shadow-[0_20px_40px_rgba(0,0,0,0.6)]" />
      </motion.div>

      {/* Moon */}
      <motion.div
        className="absolute top-[10%] right-[12%] w-20 h-20 sm:w-28 sm:h-28 rounded-full bg-gradient-to-br from-[#fff8d0] to-[#f5d26c]"
        animate={{ boxShadow: ["0 0 40px rgba(255,225,120,0.5)", "0 0 80px rgba(255,225,120,0.8)", "0 0 40px rgba(255,225,120,0.5)"] }}
        transition={{ duration: 4, repeat: Infinity }}
      />

      {/* Main content */}
      <div className="relative z-20 text-center px-4 max-w-5xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <span className="hero-pill text-sm sm:text-base">
            <span className="text-[#a8ff8a]">💎</span>
            {EVENT.pill}
            <span className="text-[#a8ff8a]">💎</span>
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.15 }}
          className="supercell-title text-[clamp(3rem,12vw,9rem)] leading-none mt-6"
        >
          InnoFusion
          <br />
          <span className="text-[clamp(4rem,15vw,11rem)]">3.0</span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.45 }}
          className="mt-2"
        >
          <div className="glow-label text-xl sm:text-3xl animate-glow">
            {EVENT.tagline}
          </div>
          <p className="mt-3 text-white/75 text-sm sm:text-base italic">
            {EVENT.subTagline}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.6 }}
          className="mt-10"
        >
          <Countdown date={EVENT.targetDate} />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.9 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <a href={EVENT.registerUrl} target="_blank" rel="noreferrer" className="btn-clan">
            <Swords className="h-5 w-5" /> Register Now
          </a>
          <a href="#army" className="btn-ghost-clan">
            Explore Tracks <ArrowRight className="h-4 w-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
