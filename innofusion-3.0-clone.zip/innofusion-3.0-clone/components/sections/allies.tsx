"use client";

import { motion } from "framer-motion";
import { SPONSORS } from "@/lib/data";

const TIER_STYLES: Record<string, string> = {
  Champion: "from-[#ffe59a] via-[#ffb23a] to-[#a54c00]",
  Elite:    "from-[#caa8f5] via-[#9984d4] to-[#592e83]",
  Warrior:  "from-[#b27c66] via-[#caa8f5] to-[#9984d4]",
  Ally:     "from-[#9984d4] via-[#592e83] to-[#230c33]",
};

export function Allies() {
  const tiers = ["Champion", "Elite", "Warrior", "Ally"] as const;

  return (
    <section id="allies" className="relative py-20 sm:py-28">
      <div className="container mx-auto px-5">
        <div className="text-center mb-14">
          <div className="section-subheading">🤝 Allies</div>
          <h2 className="section-heading">Allied Clans (Sponsors)</h2>
          <p className="mt-3 max-w-2xl mx-auto text-white/70">
            The mighty clans that power the war chest. Without them, the battlefield stands empty.
          </p>
        </div>

        <div className="space-y-10">
          {tiers.map((tier) => {
            const list = SPONSORS.filter((s) => s.tier === tier);
            if (!list.length) return null;
            return (
              <div key={tier}>
                <div className="flex items-center gap-3 mb-5">
                  <div className={`h-[3px] flex-1 bg-gradient-to-r ${TIER_STYLES[tier]} rounded-full`} />
                  <div className="font-display tracking-[0.25em] uppercase text-lilac text-sm">{tier} Clan</div>
                  <div className={`h-[3px] flex-1 bg-gradient-to-r ${TIER_STYLES[tier]} rounded-full`} />
                </div>
                <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 lg:grid-cols-4">
                  {list.map((s, i) => (
                    <motion.div
                      key={s.name}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.45, delay: i * 0.05 }}
                      whileHover={{ y: -4 }}
                      className="clan-panel p-6 text-center group"
                    >
                      <div className="font-display font-black text-lilac text-lg group-hover:text-white transition">
                        {s.name}
                      </div>
                      <div className="mt-1 text-xs text-white/55 uppercase tracking-widest">{s.tier}</div>
                    </motion.div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-14 text-center">
          <div className="inline-block clan-panel px-6 py-4">
            <div className="text-xs tracking-widest uppercase text-bronze font-display">Want to sponsor?</div>
            <a href="mailto:innofusion@uem.edu.in" className="font-display text-lilac font-black hover:text-white">
              innofusion@uem.edu.in →
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
