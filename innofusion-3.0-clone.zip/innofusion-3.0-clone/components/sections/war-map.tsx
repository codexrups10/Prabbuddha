"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { SCHEDULE } from "@/lib/data";

export function WarMap() {
  return (
    <section id="war-map" className="relative py-20 sm:py-28 overflow-hidden">
      <Image
        src="/images/War_Map_Background.webp"
        alt=""
        fill
        sizes="100vw"
        className="object-cover object-center opacity-30"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-abyss via-abyss/70 to-abyss" />
      <div className="starfield" />

      <div className="container relative mx-auto px-5">
        <div className="text-center mb-14">
          <div className="section-subheading">⏱ War Map</div>
          <h2 className="section-heading">Battle Timeline &amp; Schedule</h2>
          <p className="mt-3 max-w-2xl mx-auto text-white/70">
            From the moment the gates open to the grand finale in Kolkata, here&apos;s every milestone in the clan war.
          </p>
        </div>

        <div className="relative">
          {/* Center vertical line (desktop) */}
          <div className="hidden md:block absolute left-1/2 top-4 bottom-4 w-[3px] bg-gradient-to-b from-lilac/0 via-lilac to-lilac/0 -translate-x-1/2" />

          <div className="space-y-10 md:space-y-20">
            {SCHEDULE.map((item, i) => {
              const left = i % 2 === 0;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 40 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-80px" }}
                  transition={{ duration: 0.6, delay: i * 0.05 }}
                  className={`grid md:grid-cols-2 gap-6 items-center ${left ? "" : "md:[&>*:first-child]:order-2"}`}
                >
                  <div className={`flex ${left ? "md:justify-end" : "md:justify-start"}`}>
                    <div className="clan-panel p-6 max-w-md w-full">
                      <div className="flex items-center gap-4">
                        <div className="relative w-20 h-20 shrink-0">
                          <Image src={item.image} alt={item.title} fill className="object-contain drop-shadow-[0_6px_12px_rgba(0,0,0,0.6)]" />
                        </div>
                        <div>
                          <div className="text-xs font-display tracking-widest uppercase text-bronze">{`Stage ${i + 1}`}</div>
                          <h3 className="font-display text-xl sm:text-2xl font-black text-lilac mt-0.5">{item.title}</h3>
                          <div className="text-sm text-white/70 font-display">{item.date}</div>
                        </div>
                      </div>
                      <p className="mt-4 text-white/75 leading-relaxed text-sm">{item.description}</p>
                    </div>
                  </div>

                  {/* Dot on timeline */}
                  <div className="hidden md:flex items-center relative">
                    <div className="absolute left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-lilac shadow-[0_0_0_4px_rgba(35,12,51,0.9),0_0_22px_rgba(202,168,245,0.8)]" />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
