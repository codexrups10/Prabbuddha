"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { PRIZES, PRIZE_POOL_TOTAL, PERKS } from "@/lib/data";
import { Trophy, Sparkles } from "lucide-react";

export function Treasury() {
  return (
    <section id="treasury" className="relative py-20 sm:py-28 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(202,168,245,0.15),transparent_60%)]" />
      <div className="container relative mx-auto px-5">
        <div className="text-center mb-14">
          <div className="section-subheading">💰 Treasury</div>
          <h2 className="section-heading">Loot &amp; Rewards Await!</h2>
          <p className="mt-3 max-w-2xl mx-auto text-white/70">
            A prize pool of{" "}
            <span className="font-display text-lilac font-black">{PRIZE_POOL_TOTAL}</span>{" "}
            across track prizes, premium partner bounties, swag and the Grand Champion trophy.
          </p>
        </div>

        {/* Grand pool badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mx-auto mb-14 relative max-w-md"
        >
          <div className="clan-panel shine p-8 text-center">
            <div className="relative w-32 h-32 mx-auto">
              <Image src="/images/TrophyIcon.webp" alt="trophy" fill className="object-contain" />
            </div>
            <div className="mt-4 text-sm font-display tracking-widest uppercase text-bronze">Total Prize Pool</div>
            <div className="font-display text-5xl font-black text-lilac mt-1 drop-shadow-[0_3px_0_#230c33]">
              {PRIZE_POOL_TOTAL}
            </div>
            <div className="mt-2 text-xs text-white/60 flex items-center justify-center gap-2">
              <Sparkles className="h-3.5 w-3.5 text-bronze" />
              Sponsored bounties + track prizes
            </div>
          </div>
        </motion.div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {PRIZES.map((p, i) => (
            <motion.div
              key={p.sponsor + p.rank}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.04 }}
              whileHover={{ y: -4 }}
              className="clan-panel p-5 relative overflow-hidden group"
            >
              <div className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${p.accent}`} />
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-xs font-display tracking-widest uppercase text-bronze">{p.sponsor}</div>
                  <h3 className="font-display font-black text-lilac text-lg mt-1">{p.rank}</h3>
                </div>
                <Trophy className="h-6 w-6 text-lilac/80 shrink-0" />
              </div>
              <div className="mt-4 font-display text-3xl font-black bg-gradient-to-r from-[#ffe59a] via-[#ffb23a] to-[#a54c00] bg-clip-text text-transparent">
                {p.amount}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Perks grid */}
        <div className="mt-16 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {PERKS.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
              className="clan-panel p-5"
            >
              <div className="font-display text-sm tracking-wide uppercase text-bronze">Perk</div>
              <h4 className="mt-1 font-display font-black text-lilac text-lg">{p.title}</h4>
              <p className="mt-2 text-sm text-white/75 leading-relaxed">{p.body}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
