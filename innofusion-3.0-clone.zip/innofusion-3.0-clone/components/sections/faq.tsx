"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { FAQS } from "@/lib/data";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";

export function FAQ() {
  return (
    <section id="faq" className="relative py-20 sm:py-28">
      <div className="container mx-auto px-5 grid gap-10 lg:grid-cols-[0.9fr_1.1fr] items-start">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="relative"
        >
          <div className="section-subheading mb-3">❓ FAQ</div>
          <h2 className="section-heading">Battlefield Intel</h2>
          <p className="mt-3 text-white/70 max-w-md">
            Everything a warrior needs to know before marching on Kolkata.
          </p>

          <div className="relative w-full max-w-sm mt-10">
            <Image
              src="/images/TorchCampfire.webp"
              alt=""
              width={400}
              height={400}
              className="drop-shadow-[0_20px_40px_rgba(178,124,102,0.4)]"
            />
            <div className="absolute -inset-10 bg-[radial-gradient(ellipse_at_center,rgba(255,170,80,0.25),transparent_70%)] animate-pulse-slow -z-10" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <Accordion type="single" collapsible className="flex flex-col gap-3">
            {FAQS.map((f, i) => (
              <AccordionItem key={i} value={`item-${i}`}>
                <AccordionTrigger>{f.q}</AccordionTrigger>
                <AccordionContent>{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
}
