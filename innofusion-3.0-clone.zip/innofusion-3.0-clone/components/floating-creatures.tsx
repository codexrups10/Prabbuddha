"use client";

import Image from "next/image";
import { motion } from "framer-motion";

/** Floating decorative characters across the page (dragons, etc.) */
export function FloatingCreatures() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <motion.div
        className="absolute top-[10%] left-[-60px] w-[140px] opacity-80"
        animate={{ x: ["-20%", "120vw"], y: [0, -20, 0, 20, 0] }}
        transition={{ duration: 28, repeat: Infinity, ease: "linear" }}
      >
        <Image src="/images/Dragon.webp" alt="" width={240} height={140} className="drop-shadow-[0_10px_25px_rgba(0,0,0,0.6)]" />
      </motion.div>
      <motion.div
        className="absolute top-[55%] right-[-100px] w-[150px] opacity-80"
        animate={{ x: ["20%", "-120vw"], y: [0, 20, 0, -20, 0] }}
        transition={{ duration: 36, repeat: Infinity, ease: "linear", delay: 4 }}
      >
        <Image src="/images/DragonElectro_Dragon-removebg-preview.webp" alt="" width={260} height={140} className="drop-shadow-[0_10px_25px_rgba(0,0,0,0.6)]" />
      </motion.div>
    </div>
  );
}
