"use client";

import { Volume2, VolumeX } from "lucide-react";
import { useUI } from "@/lib/store";
import { motion } from "framer-motion";

export function AudioToggle() {
  const { audioOn, toggleAudio } = useUI();
  return (
    <motion.button
      aria-label="Toggle audio"
      onClick={toggleAudio}
      initial={{ opacity: 0, scale: 0.6 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 1.5 }}
      whileHover={{ scale: 1.08 }}
      whileTap={{ scale: 0.9 }}
      className="fixed bottom-5 right-5 z-40 h-12 w-12 grid place-items-center rounded-xl border-2 border-[#6a2b00] bg-gradient-to-b from-[#ffd447] to-[#c46700] shadow-[0_4px_0_#6a2b00,0_6px_18px_rgba(0,0,0,0.4)]"
    >
      {audioOn ? (
        <Volume2 className="h-5 w-5 text-[#2a1002]" />
      ) : (
        <VolumeX className="h-5 w-5 text-[#2a1002]" />
      )}
    </motion.button>
  );
}
