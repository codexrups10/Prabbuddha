import type { Metadata } from "next";
import { Orbitron, Rubik } from "next/font/google";
import "./globals.css";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { AudioToggle } from "@/components/audio-toggle";

const orbitron = Orbitron({
  subsets: ["latin"],
  weight: ["400", "500", "700", "800", "900"],
  variable: "--font-orbitron",
  display: "swap",
});

const rubik = Rubik({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-rubik",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://www.innofusion.tech"),
  title:
    "InnoFusion 3.0 | The Clan Wars — 30-Hour India's Premier Software + Hardware Hackathon",
  description:
    "Join InnoFusion 3.0, the ultimate 30-hour India's Premier Software + Hardware Hackathon at UEM Kolkata. Clash with codes, conquer with vision. July 25-26, 2026.",
  keywords: [
    "InnoFusion",
    "InnoFusion 3.0",
    "UEM Kolkata",
    "Hackathon",
    "Clash of Clans",
    "Software Hackathon",
    "Hardware Hackathon",
    "Devfolio",
  ],
  openGraph: {
    title: "InnoFusion 3.0 | The Clan Wars",
    description:
      "30-Hour India's Premier Software + Hardware Hackathon. Clash with Codes, Conquer with Vision!",
    url: "https://www.innofusion.tech",
    siteName: "InnoFusion 3.0",
    images: [{ url: "/images/Innofusion3.0_Logo.webp", width: 1200, height: 630 }],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "InnoFusion 3.0 | The Clan Wars",
    description:
      "30-Hour India's Premier Software + Hardware Hackathon at UEM Kolkata.",
    images: ["/images/Innofusion3.0_Logo.webp"],
  },
  icons: { icon: "/images/Innofusion3.0_Logo.webp" },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${orbitron.variable} ${rubik.variable}`}>
      <body>
        <Navbar />
        <main className="relative overflow-x-hidden">{children}</main>
        <Footer />
        <AudioToggle />
      </body>
    </html>
  );
}
