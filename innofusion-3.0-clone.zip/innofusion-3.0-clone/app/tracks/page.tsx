"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { TRACKS, EVENT } from "@/lib/data";
import { ArrowLeft, Swords } from "lucide-react";

export default function TracksPage() {
  return (
    <div className="pt-28 pb-20">
      <div className="relative py-14 overflow-hidden">
        <div className="starfield" />
        <div className="container mx-auto px-5 text-center relative">
          <div className="section-subheading">🗡 Army</div>
          <h1 className="section-heading mt-2">Deploy Your Troops</h1>
          <p className="mt-4 max-w-2xl mx-auto text-white/75">
            Choose a domain, rally your clan, and ship something legendary in 30 hours.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-5">
        <div className="grid gap-6 md:grid-cols-2">
          {TRACKS.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.55, delay: i * 0.06 }}
              whileHover={{ y: -6 }}
              className="clan-panel p-6 sm:p-8 relative overflow-hidden flex gap-5 items-start"
            >
              <div className="relative w-28 h-28 sm:w-36 sm:h-36 shrink-0">
                <Image src={t.image} alt={t.name} fill className="object-contain drop-shadow-[0_10px_25px_rgba(0,0,0,0.5)]" />
              </div>
              <div>
                <div className="text-4xl">{t.icon}</div>
                <h3 className="mt-2 font-display text-2xl font-black text-lilac">{t.name}</h3>
                <p className="mt-2 text-white/75 leading-relaxed">{t.description}</p>
                <div className="mt-4 inline-flex items-center gap-2 text-sm font-display uppercase tracking-widest text-bronze">
                  <Swords className="h-4 w-4" />
                  Join this track
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-14 flex flex-wrap items-center justify-center gap-4">
          <Link href="/" className="btn-ghost-clan">
            <ArrowLeft className="h-4 w-4" /> Back to Village
          </Link>
          <a href={EVENT.registerUrl} target="_blank" rel="noreferrer" className="btn-clan">
            <Swords className="h-5 w-5" /> Register Now
          </a>
        </div>
      </div>
    </div>
  );
}
