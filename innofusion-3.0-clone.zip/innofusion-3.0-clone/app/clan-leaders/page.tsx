"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { CLAN_LEADERS } from "@/lib/data";
import { Crown } from "lucide-react";

type Leader = { name: string; role: string };

const GROUPS: { title: string; members: readonly Leader[] }[] = [
  { title: "Organizers",    members: CLAN_LEADERS.organizers },
  { title: "Developers",    members: CLAN_LEADERS.developers },
  { title: "Core Team",     members: CLAN_LEADERS.core },
  { title: "Graphics Team", members: CLAN_LEADERS.graphics },
  { title: "Branding Team", members: CLAN_LEADERS.branding },
  { title: "PR Team",       members: CLAN_LEADERS.pr },
  { title: "Decoration",    members: CLAN_LEADERS.decoration },
  { title: "Coordinators",  members: CLAN_LEADERS.coordinators },
  { title: "Executive",     members: CLAN_LEADERS.executive },
];

function initials(name: string) {
  return name
    .split(" ")
    .slice(0, 2)
    .map((s) => s[0])
    .join("")
    .toUpperCase();
}

export default function ClanLeadersPage() {
  return (
    <div className="relative pt-28 pb-20">
      {/* Hero */}
      <div className="relative py-16 overflow-hidden">
        <div className="starfield" />
        <div className="container mx-auto px-5 text-center relative">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 mb-4"
          >
            <Image src="/images/UEM.webp" alt="UEM" width={48} height={48} className="h-12 w-12 object-contain" />
            <Image src="/images/IEM.webp" alt="IEM" width={48} height={48} className="h-12 w-12 object-contain" />
            <Image src="/images/Innofusion3.0_Logo.webp" alt="InnoFusion" width={56} height={56} className="h-14 w-14 object-contain drop-shadow-[0_0_14px_rgba(202,168,245,0.6)]" />
          </motion.div>
          <div className="section-subheading">👑 The Clan Leaders</div>
          <h1 className="section-heading mt-2">Meet the Mighty Warriors</h1>
          <p className="mt-4 max-w-2xl mx-auto text-white/75">
            The strategists, builders and battle chiefs who lead our InnoFusion clan to victory.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-5 space-y-14">
        {GROUPS.map((group, gi) => (
          <section key={group.title}>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="flex items-center gap-3 mb-6"
            >
              <Crown className="h-5 w-5 text-lilac" />
              <h2 className="font-display text-2xl sm:text-3xl font-black text-lilac tracking-wide">
                {group.title}
              </h2>
              <div className="flex-1 h-[2px] bg-gradient-to-r from-lilac/50 to-transparent rounded-full" />
            </motion.div>

            <div className="grid gap-5 grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
              {group.members.map((m, i) => (
                <motion.div
                  key={m.name}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.45, delay: (gi * 0.02) + i * 0.04 }}
                  whileHover={{ y: -6 }}
                  className="clan-panel p-5 text-center group"
                >
                  <div className="relative mx-auto w-24 h-24 rounded-full bg-gradient-to-br from-lilac to-royal grid place-items-center shadow-[0_0_0_4px_rgba(35,12,51,0.8),0_0_24px_rgba(202,168,245,0.4)] overflow-hidden">
                    <span className="font-display text-2xl font-black text-white drop-shadow-[0_2px_0_#230c33]">
                      {initials(m.name)}
                    </span>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                  </div>
                  <h3 className="mt-4 font-display font-black text-lilac text-base leading-tight">
                    {m.name}
                  </h3>
                  <div className="mt-1 text-xs font-display tracking-widest uppercase text-bronze">
                    {m.role}
                  </div>
                </motion.div>
              ))}
            </div>
          </section>
        ))}
      </div>

      <div className="mt-16 text-center">
        <div className="inline-flex items-center gap-2 clan-panel px-6 py-3 font-display tracking-widest uppercase text-lilac">
          🛡 &quot;Clash with Codes, Conquer with Vision! ~&quot; ✦
        </div>
      </div>
    </div>
  );
}
