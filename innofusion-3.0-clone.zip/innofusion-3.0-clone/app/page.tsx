import { Hero } from "@/components/sections/hero";
import { About } from "@/components/sections/about";
import { WarMap } from "@/components/sections/war-map";
import { Army } from "@/components/sections/army";
import { Treasury } from "@/components/sections/treasury";
import { Allies } from "@/components/sections/allies";
import { FAQ } from "@/components/sections/faq";
import { CTA } from "@/components/sections/cta";
import { FloatingCreatures } from "@/components/floating-creatures";

export default function HomePage() {
  return (
    <>
      <Hero />
      <div className="relative">
        <FloatingCreatures />
        <About />
        <WarMap />
        <Army />
        <Treasury />
        <Allies />
        <FAQ />
        <CTA />
      </div>
    </>
  );
}
