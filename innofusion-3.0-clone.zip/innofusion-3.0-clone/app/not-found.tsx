import Link from "next/link";
import Image from "next/image";

export default function NotFound() {
  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center text-center px-5 pt-24">
      <Image
        src="/images/ShieldClan_Badge_Icon.webp"
        alt=""
        width={180}
        height={180}
        className="drop-shadow-[0_20px_40px_rgba(202,168,245,0.3)]"
      />
      <h1 className="supercell-title text-6xl sm:text-8xl mt-6">404</h1>
      <p className="mt-4 text-white/80 font-display tracking-widest uppercase">Oops! Page not found</p>
      <Link href="/" className="btn-clan mt-8">Return to Home</Link>
    </div>
  );
}
